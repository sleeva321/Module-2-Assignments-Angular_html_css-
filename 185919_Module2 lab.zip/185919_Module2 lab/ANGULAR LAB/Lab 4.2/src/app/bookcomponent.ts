Component


import { Component,OnInit } from '@angular/core';
import { Book } from './Book';
import { BookService } from './app.mobileservice';

@Component({
    selector:'book-app',
    templateUrl:'./mobile.html',
    providers:[BookService]
})
export class BookComponent implements OnInit{

    bookData:Book[];
    // searchedData:Book[];
    searchedId:any;
    searchedId2:any;
    searchedId3:any;
    searchedId4:any;
    searchedId5:any;


    flag = 0;

    constructor(private _bookservice:BookService){

    }
    ngOnInit(){
        this._bookservice.getAllBookDetail().
        subscribe((data:Book[])=>{
            this.bookData=data;
            console.log("");
        });
    }

}